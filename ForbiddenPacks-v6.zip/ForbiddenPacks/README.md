# Forbidden Packs

Gacha · Battle · Mines · Collection — static single-page game. No build step: open `index.html`
(or serve the folder, e.g. `python3 -m http.server 8080`).

```
index.html      markup only
css/styles.css  all styles
js/cards.js     card data (edit/add cards here)
js/game.js      game logic — balance numbers are in the CONFIG block at the top
cards/          card images
```

## Where to tune things (top of `js/game.js`)
| What | Constant |
|---|---|
| Pack prices, odds, guaranteed minimum rarity | `PACKS` |
| Dupe sell prices | `SELL_VALUE` |
| Daily bonus | `DAILY` |
| Mines modes + payout | `MINE_MODES`, `MINE_REWARD` |
| Bot difficulty curve / how much bots mirror your team | `LEVELS`, `BOT_RELATIVE_WEIGHT`, `PERSONAS` |
| Type matchup strength | `TYPE_EDGE`, `TYPE_PENALTY`, `WILD_BONUS` |
| Battle coin rewards / cooldown | `battleReward()`, `battleCooldownMs()` |

## Saves
Progress lives in `localStorage` under `fp_save_v6`. Saves from the old build (`fp_*` keys) are
imported automatically the first time. Use **Collection → Export backup** to move progress between devices.
