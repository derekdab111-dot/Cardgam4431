'use strict';
/* =====================================================================
   Forbidden Packs — game logic
   Data: js/cards.js (CARDS)   Styles: css/styles.css
   Sections: config · utils · state · economy · packs · battle · mines ·
             collection/catalog · modal · wiring
   Tuning: every balance number lives in the CONFIG block below.
   ===================================================================== */

/* ===================== CONFIG ===================== */
const SAVE_KEY = 'fp_save_v6';
const CHUNK = 48; // cards rendered per "page" in big grids
const TS_MAX = 1e15; // upper bound for stored timestamps (ms)

const RARITIES = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic', 'ethereal'];
const RARITY_POWER = { common: 10, uncommon: 18, rare: 30, epic: 48, legendary: 75, mythic: 120, ethereal: 175 };
const RARITY_COLOR = {
  common: '#9ca3af', uncommon: '#4ade80', rare: '#60a5fa', epic: '#c084fc',
  legendary: '#ffd700', mythic: '#ff6b9d', ethereal: '#e9d5ff'
};
const TYPE_MOD = { Assault: 1.22, Guardian: 0.88, Support: 1.0, Temptress: 1.14, Wild: 1.06 };

// Type triangle: key beats value. Wild is neutral but gets a flat bonus.
const TYPE_BEATS = { Assault: 'Support', Temptress: 'Guardian', Guardian: 'Assault' };
const TYPE_EDGE = 1.15;      // multiplier when your type beats theirs
const TYPE_PENALTY = 0.92;   // multiplier when their type beats yours
const WILD_BONUS = 1.05;

const PACKS = [
  { id: 'standard', name: 'Standard', icon: '📦', cost: 120, cards: 5, floor: 'rare',
    weights: { common: 40, uncommon: 28, rare: 18, epic: 9, legendary: 4, mythic: 0.8, ethereal: 0.2 },
    info: '5 cards · basic odds' },
  { id: 'premium', name: 'Premium', icon: '💎', cost: 280, cards: 5, floor: 'rare',
    weights: { common: 18, uncommon: 22, rare: 24, epic: 20, legendary: 11, mythic: 4, ethereal: 1 },
    info: '5 cards · better rares+' },
  { id: 'forbidden', name: 'Forbidden', icon: '🔥', cost: 550, cards: 5, floor: 'epic',
    weights: { common: 5, uncommon: 12, rare: 20, epic: 28, legendary: 22, mythic: 10, ethereal: 3 },
    info: '5 cards · stacked high tiers' },
  { id: 'ethereal', name: 'Ethereal', icon: '✦', cost: 900, cards: 3, floor: 'legendary',
    weights: { common: 0, uncommon: 0, rare: 8, epic: 25, legendary: 35, mythic: 22, ethereal: 10 },
    info: '3 cards · mythic/ethereal focus' }
];
const QTY_OPTIONS = [1, 5, 10];

// Coins you get for selling a spare copy (one copy of each card is always kept).
const SELL_VALUE = { common: 4, uncommon: 8, rare: 18, epic: 35, legendary: 80, mythic: 180, ethereal: 350 };

const DAILY = { base: 80, step: 20, maxDays: 7, cooldownHours: 20, graceHours: 48 };

const MINE_MODES = {
  easy:   { label: 'Easy · 9×9 · 10 mines',   size: 9,  mines: 10, mult: 1.0 },
  medium: { label: 'Medium · 9×9 · 15 mines', size: 9,  mines: 15, mult: 1.6 },
  hard:   { label: 'Hard · 11×11 · 28 mines', size: 11, mines: 28, mult: 2.6 }
};
const MINE_REWARD = { base: 32, spread: 28 };   // × mode multiplier

// Bots: index = level-1. `power` is the absolute target card power at that level.
const LEVELS = [
  { name: 'Easy', power: 22 }, { name: 'Normal', power: 30 }, { name: 'Hard', power: 40 },
  { name: 'Elite', power: 52 }, { name: 'Nightmare', power: 66 }, { name: 'Demon', power: 82 },
  { name: 'God', power: 100 }, { name: 'Forbidden', power: 118 }, { name: 'Abyss', power: 138 },
  { name: 'Final', power: 160 }
];
const BOT_RELATIVE_WEIGHT = 0.4; // how much the bot mirrors YOUR team power (rest is level-based)
const PERSONAS = [
  { name: 'Brawler',    likes: ['Assault', 'Wild'] },
  { name: 'Warden',     likes: ['Guardian', 'Support'] },
  { name: 'Trickster',  likes: ['Temptress', 'Wild'] },
  { name: 'Strategist', likes: [] },
  { name: 'Wildcard',   likes: ['Wild'] }
];

/* ===================== UTILS ===================== */
const $ = id => document.getElementById(id);
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const rand = (lo, hi) => lo + Math.floor(Math.random() * (hi - lo + 1));
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fmt = n => Number(n).toLocaleString();
const rarIdx = r => RARITIES.indexOf(r);
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);

/** Tiny DOM builder: h('div', {class:'x', onclick:fn}, child, ...) — text is always set safely. */
function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k === 'style') Object.assign(el.style, v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}

/* ===================== CARD INDEX ===================== */
const CARD_BY_ID = new Map(CARDS.map(c => [c.id, c]));
const POOL = Object.fromEntries(RARITIES.map(r => [r, CARDS.filter(c => c.rarity === r)]));
const PACK_BY_ID = Object.fromEntries(PACKS.map(p => [p.id, p]));
const _power = new Map();
/** Deterministic base power of a card (no randomness). */
function cardPower(c) {
  let p = _power.get(c.id);
  if (p === undefined) {
    const g = 1 + Math.min(0.12, (c.girls || 1) * 0.03);
    p = Math.round((RARITY_POWER[c.rarity] || 20) * (TYPE_MOD[c.type] || 1) * g);
    _power.set(c.id, p);
  }
  return p;
}

/* ===================== STATE ===================== */
const defaultState = () => ({
  v: 6, coins: 350, packs: 0, collection: {}, wins: 0, losses: 0, streak: 0, bestStreak: 0,
  battleCD: 0, team: [], dailyAt: 0, dailyStreak: 0, minesCleared: 0,
  mineMode: 'easy', botLevel: 'auto', packId: 'standard', qty: 1
});

/** Validates anything (old save, imported file, other tab) into a safe state object. */
function sanitize(raw) {
  const d = defaultState();
  if (!raw || typeof raw !== 'object') return d;
  const num = (v, def, lo = 0, hi = 1e12) => (v !== undefined && v !== null && v !== '' && Number.isFinite(+v)) ? clamp(Math.floor(+v), lo, hi) : def;
  d.coins = num(raw.coins, d.coins);
  d.packs = num(raw.packs, 0);
  d.wins = num(raw.wins, 0);
  d.losses = num(raw.losses, 0);
  d.streak = num(raw.streak, 0, 0, 9999);
  d.bestStreak = Math.max(d.streak, num(raw.bestStreak, 0, 0, 9999));
  d.battleCD = num(raw.battleCD, 0, 0, TS_MAX);
  d.dailyAt = num(raw.dailyAt, 0, 0, TS_MAX);
  d.dailyStreak = num(raw.dailyStreak, 0, 0, 9999);
  d.minesCleared = num(raw.minesCleared, 0);
  if (raw.collection && typeof raw.collection === 'object') {
    for (const [id, e] of Object.entries(raw.collection)) {
      const n = Number(id);
      if (!CARD_BY_ID.has(n)) continue;
      const count = num(e && e.count, 0, 0, 9999);
      if (count > 0) d.collection[n] = { count, first: num(e && e.first, 0, 0, TS_MAX) };
    }
  }
  d.team = Array.isArray(raw.team) ? [...new Set(raw.team.map(Number))].filter(id => d.collection[id]).slice(0, 3) : [];
  if (MINE_MODES[raw.mineMode]) d.mineMode = raw.mineMode;
  if (raw.botLevel === 'auto' || (+raw.botLevel >= 1 && +raw.botLevel <= LEVELS.length)) d.botLevel = String(raw.botLevel);
  if (PACK_BY_ID[raw.packId]) d.packId = raw.packId;
  if (QTY_OPTIONS.includes(+raw.qty)) d.qty = +raw.qty;
  return d;
}

/** Imports progress from the pre-v6 build (separate localStorage keys). */
function migrateLegacy() {
  const get = k => { try { const v = localStorage.getItem(k); return v === null ? undefined : v; } catch { return undefined; } };
  if (get('fp_collection_v5') === undefined && get('fp_coins') === undefined) return defaultState();
  let col = {};
  try { col = JSON.parse(get('fp_collection_v5') || '{}'); } catch { /* ignore */ }
  return sanitize({
    coins: get('fp_coins'), packs: get('fp_packs'), collection: col, wins: get('fp_wins'),
    losses: get('fp_losses'), streak: get('fp_streak'), battleCD: get('fp_battle_cd')
  });
}

function loadState() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) return sanitize(JSON.parse(raw));
  } catch { /* corrupt save → fall through */ }
  return migrateLegacy();
}

let S = loadState();
let saveTimer = null;
function flush() {
  clearTimeout(saveTimer); saveTimer = null;
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(S)); } catch { /* storage full / private mode */ }
}
function save() { if (!saveTimer) saveTimer = setTimeout(flush, 150); }
addEventListener('pagehide', flush);
document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });

/* ===================== TOAST ===================== */
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._t);
  t._t = setTimeout(() => t.classList.remove('show'), 2400);
}

/* ===================== ECONOMY ===================== */
function addCoins(n) { S.coins += n; save(); renderTop(); }

function dailyReady() { return Date.now() - S.dailyAt >= DAILY.cooldownHours * 3600e3; }
function dailyReward(nextStreak) { return DAILY.base + DAILY.step * (Math.min(nextStreak, DAILY.maxDays) - 1); }
function claimDaily() {
  if (!dailyReady()) return;
  const within = Date.now() - S.dailyAt <= DAILY.graceHours * 3600e3;
  S.dailyStreak = (S.dailyAt && within) ? S.dailyStreak + 1 : 1;
  S.dailyAt = Date.now();
  const r = dailyReward(S.dailyStreak);
  addCoins(r);
  renderDaily();
  toast(`Daily +${r} 💰 (day ${Math.min(S.dailyStreak, DAILY.maxDays)})`);
}
function renderDaily() {
  const b = $('dailyBtn');
  if (dailyReady()) {
    const nextStreak = (S.dailyAt && Date.now() - S.dailyAt <= DAILY.graceHours * 3600e3) ? S.dailyStreak + 1 : 1;
    b.disabled = false;
    b.textContent = `🎁 Daily +${dailyReward(nextStreak)}`;
  } else {
    const ms = DAILY.cooldownHours * 3600e3 - (Date.now() - S.dailyAt);
    const hh = Math.floor(ms / 3600e3), mm = Math.floor((ms % 3600e3) / 60e3);
    b.disabled = true;
    b.textContent = `🎁 ${hh}h ${String(mm).padStart(2, '0')}m`;
  }
}

function renderTop() {
  $('coinCount').textContent = fmt(S.coins);
  $('packsOpened').textContent = fmt(S.packs);
  $('wlRecord').textContent = `${S.wins}-${S.losses}`;
  renderPackButton();
  renderPackOptions();
}

/* ===================== PACKS ===================== */
let opening = false;

/** Rarities with no cards in CARDS fold their drop-rate into the next populated tier up
 *  (the old build rolled "any card" instead, so 40% of Standard pulls ignored rarity). */
function effectiveWeights(weights) {
  const populated = RARITIES.filter(r => POOL[r].length);
  const out = {};
  RARITIES.forEach((r, i) => {
    const w = weights[r] || 0;
    if (!w) return;
    const target = populated.find(p => rarIdx(p) >= i) || populated[populated.length - 1];
    out[target] = (out[target] || 0) + w;
  });
  return out;
}

function pickCard(weights, minRarity) {
  const eff = effectiveWeights(weights);
  const entries = Object.entries(eff).filter(([r]) => !minRarity || rarIdx(r) >= rarIdx(minRarity));
  if (!entries.length) return pick(CARDS);
  let roll = Math.random() * entries.reduce((s, [, w]) => s + w, 0);
  for (const [r, w] of entries) { roll -= w; if (roll <= 0) return pick(POOL[r]); }
  return pick(POOL[entries[entries.length - 1][0]]);
}

function drawPack(pack) {
  const cards = Array.from({ length: pack.cards }, () => pickCard(pack.weights));
  if (!cards.some(c => rarIdx(c.rarity) >= rarIdx(pack.floor))) {
    cards[cards.length - 1] = pickCard(pack.weights, pack.floor); // guaranteed floor
  }
  return cards;
}

function freePackAvailable(pack) { return pack.id === 'standard' && S.packs === 0; }
function packCost(pack, qty) { return pack.cost * qty - (freePackAvailable(pack) ? pack.cost : 0); }

function renderPackOptions() {
  const wrap = $('packOptions');
  wrap.replaceChildren(...PACKS.map(p => {
    const free = freePackAvailable(p);
    const can = S.coins >= (free ? 0 : p.cost);
    return h('button', {
      type: 'button',
      class: 'pack-card' + (S.packId === p.id ? ' selected' : '') + (can ? '' : ' locked'),
      'aria-disabled': can ? null : 'true',
      'aria-pressed': S.packId === p.id ? 'true' : 'false',
      onclick: () => { if (!can) { toast('Not enough coins'); return; } S.packId = p.id; save(); renderTop(); renderOdds(); }
    },
      h('div', { class: 'pack-icon', text: p.icon }),
      h('h3', { text: p.name }),
      h('div', { class: 'pack-price', text: free ? 'FREE' : `${fmt(p.cost)} 💰` }),
      h('div', { class: 'pack-info', text: p.info }));
  }));
  document.querySelectorAll('[data-qty]').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.qty === S.qty)));
}

function renderPackButton() {
  const pack = PACK_BY_ID[S.packId], btn = $('openPackBtn');
  const cost = packCost(pack, S.qty);
  btn.textContent = cost === 0 ? `Open ${pack.name} — FREE` : `Open ${S.qty > 1 ? '×' + S.qty + ' ' : ''}${pack.name} (${fmt(cost)} 💰)`;
  btn.disabled = opening || S.coins < cost;
}

function renderOdds() {
  const pack = PACK_BY_ID[S.packId];
  const eff = effectiveWeights(pack.weights);
  const total = Object.values(eff).reduce((a, b) => a + b, 0);
  const rows = RARITIES.filter(r => eff[r]).reverse().map(r =>
    h('tr', {}, h('td', { style: { color: RARITY_COLOR[r] }, text: cap(r) }), h('td', { text: (eff[r] / total * 100).toFixed(1) + '%' })));
  $('oddsBody').replaceChildren(
    h('table', {}, ...rows),
    h('p', { class: 'hint', text: `Each pack guarantees at least one ${pack.floor}+ card.` }));
}

async function openPacks() {
  if (opening) return;
  const pack = PACK_BY_ID[S.packId], qty = S.qty, cost = packCost(pack, qty);
  if (S.coins < cost) { toast('Not enough coins'); return; }
  opening = true;
  S.coins -= cost;
  S.packs += qty;

  // Roll + apply immediately so progress is saved even if the tab closes mid-animation.
  const pulls = [];
  for (let q = 0; q < qty; q++) {
    for (const card of drawPack(pack)) {
      const e = S.collection[card.id];
      const isNew = !e;
      if (e) e.count++; else S.collection[card.id] = { count: 1, first: Date.now() };
      pulls.push({ card, isNew });
    }
  }
  flush();
  renderTop();

  const results = $('pullResults');
  results.replaceChildren();
  const list = pulls.map(p => p.card);
  const delay = Math.max(25, Math.min(90, 1400 / pulls.length));
  for (let i = 0; i < pulls.length; i++) {
    const { card, isNew } = pulls[i];
    const el = cardEl(card, { animate: true, list, index: i });
    if (isNew) el.append(h('div', { class: 'new-badge', text: 'NEW' }));
    results.append(el);
    await sleep(delay);
  }
  const best = pulls.reduce((a, b) => rarIdx(b.card.rarity) > rarIdx(a.card.rarity) ? b : a);
  const newCount = pulls.filter(p => p.isNew).length;
  $('pullSummary').replaceChildren(
    `${pulls.length} cards · ${newCount} new · best: `,
    h('b', { text: cap(best.card.rarity), style: { color: RARITY_COLOR[best.card.rarity] } }));
  opening = false;
  renderPackButton();
}

/* ===================== CARD ELEMENT ===================== */
/** opts: {animate, list, index, power, selected, onclick} — list/index power modal next/prev. */
function cardEl(card, opts = {}) {
  const img = h('img', { src: card.img, alt: '', loading: 'lazy', decoding: 'async' });
  img.addEventListener('error', () => img.classList.add('broken'));
  const badges = [];
  if (card.cross) badges.push(h('div', { class: 'cross-badge', text: 'CROSS' }));
  else if (card.girls >= 2) badges.push(h('div', { class: 'girls-badge', text: `${card.girls}♀` }));
  if (opts.power) badges.push(h('div', { class: 'pwr-badge', text: `⚔ ${cardPower(card)}` }));
  const el = h('button', {
    type: 'button', class: `card rarity-${card.rarity}${opts.selected ? ' selected' : ''}`,
    title: card.name, 'aria-label': `${card.name}, ${card.rarity} ${card.type}`
  },
    ...badges, img,
    h('div', { class: 'card-info' },
      h('div', { class: 'card-name', text: card.name }),
      h('div', { class: 'card-meta' },
        h('span', { class: 'rarity-bar', text: card.rarity }),
        h('span', { class: 'type-tag', text: card.type }))));
  if (opts.animate) el.style.animation = 'fadeIn .28s ease';
  el.addEventListener('click', opts.onclick || (() => openModal(opts.list || [card], opts.index || 0, el)));
  return el;
}

/* ===================== LAZY GRID ===================== */
/** Renders a big list in chunks; the "Show more" button also auto-fires when scrolled into view. */
function makeGrid(gridId, moreId, build) {
  const grid = $(gridId), more = $(moreId);
  let items = [], shown = 0;
  function append() {
    const next = items.slice(shown, shown + CHUNK);
    grid.append(...next.map((c, i) => build(c, shown + i, items)));
    shown += next.length;
    more.hidden = shown >= items.length;
    more.textContent = `Show more (${items.length - shown} left)`;
  }
  more.addEventListener('click', append);
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(es => { if (es[0].isIntersecting && !more.hidden) append(); }, { rootMargin: '500px' }).observe(more);
  }
  return { set(list) { items = list; shown = 0; grid.replaceChildren(); append(); }, get items() { return items; } };
}

/* ===================== BATTLE ===================== */
let fighting = false;
const teamCards = () => S.team.map(id => CARD_BY_ID.get(id)).filter(Boolean);
const autoLevel = () => clamp(1 + Math.floor((S.wins - S.losses * 0.5) / 2), 1, LEVELS.length);
const currentLevel = () => S.botLevel === 'auto' ? autoLevel() : clamp(+S.botLevel, 1, LEVELS.length);

/** Multiplier applied to card `a` when facing card `b`. */
function matchupMult(a, b) {
  let m = a.type === 'Wild' ? WILD_BONUS : 1;
  if (TYPE_BEATS[a.type] === b.type) m *= TYPE_EDGE;
  else if (TYPE_BEATS[b.type] === a.type) m *= TYPE_PENALTY;
  return m;
}
const duelPower = (a, b) => cardPower(a) * matchupMult(a, b) * (0.92 + Math.random() * 0.16);

/** Builds the bot's team: mixes level-based power with your own power, counter-picks types,
 *  and (at higher levels) orders its lineup to beat yours. */
function buildBot(playerCards, level, streak) {
  const persona = pick(PERSONAS);
  const avg = playerCards.reduce((s, c) => s + cardPower(c), 0) / playerCards.length;
  const target = (BOT_RELATIVE_WEIGHT * avg + (1 - BOT_RELATIVE_WEIGHT) * LEVELS[level - 1].power) * (1 + 0.012 * Math.min(streak, 10));
  const counterP = 0.10 + 0.08 * (level - 1);
  const chosen = [];
  for (let slot = 0; slot < 3; slot++) {
    const foe = playerCards[slot];
    const seen = new Set(chosen.map(c => c.id));
    let best = null, bestScore = -Infinity;
    for (let t = 0; t < 40; t++) {
      const c = pick(CARDS);
      if (seen.has(c.id)) continue;
      seen.add(c.id);
      let s = -Math.abs(Math.log(cardPower(c) / target)) + Math.random() * 0.05;
      if (TYPE_BEATS[c.type] === foe.type && Math.random() < counterP) s += 0.35;
      if (persona.likes.includes(c.type)) s += 0.12;
      if (s > bestScore) { best = c; bestScore = s; }
    }
    chosen.push(best || pick(CARDS.filter(c => !chosen.includes(c))));
  }
  const smartP = 0.15 + 0.08 * (level - 1);
  const order = Math.random() < smartP ? bestOrder(chosen, playerCards) : shuffle([...chosen]);
  return { persona, cards: order, target: Math.round(target) };
}

function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function permutations(a) { return a.length <= 1 ? [a] : a.flatMap((x, i) => permutations([...a.slice(0, i), ...a.slice(i + 1)]).map(p => [x, ...p])); }
function bestOrder(botCards, playerCards) {
  let best = botCards, bestScore = -Infinity;
  for (const perm of permutations(botCards)) {
    let wins = 0, margin = 0;
    perm.forEach((b, i) => {
      const m = cardPower(b) * matchupMult(b, playerCards[i]) - cardPower(playerCards[i]) * matchupMult(playerCards[i], b);
      if (m > 0) wins++;
      margin += m;
    });
    const score = wins * 1000 + margin;
    if (score > bestScore) { best = perm; bestScore = score; }
  }
  return best;
}

/** Pure fight resolution (no DOM / state) — reused by the balance tests. */
function resolveBattle(playerCards, level, streak) {
  const bot = buildBot(playerCards, level, streak);
  const rounds = playerCards.map((p, i) => {
    const b = bot.cards[i], pp = duelPower(p, b), bp = duelPower(b, p);
    return { player: p, bot: b, pp: Math.round(pp), bp: Math.round(bp), win: pp >= bp };
  });
  const roundWins = rounds.filter(r => r.win).length;
  return { bot, rounds, roundWins, won: roundWins >= 2 };
}

function battleReward(level, streak, won) {
  const base = 48 + level * 20 + rand(0, 29);
  if (!won) return Math.max(10, Math.round(base * 0.15));
  const tax = Math.min(0.4, streak * 0.06); // softer streak tax than before (was up to 55%)
  return Math.round(base * (1 - tax) * (1 + level * 0.04));
}
const battleCooldownMs = streak => Math.min(30000, 10000 + streak * 2000);

async function startBattle() {
  if (fighting || S.team.length !== 3 || Date.now() < S.battleCD) return;
  const level = currentLevel(), streakBefore = S.streak;
  const res = resolveBattle(teamCards(), level, streakBefore);
  const reward = battleReward(level, streakBefore, res.won);
  const tax = res.won ? Math.min(0.4, streakBefore * 0.06) : 0;

  fighting = true;
  S.battleCD = Date.now() + battleCooldownMs(streakBefore);
  S.coins += reward;
  if (res.won) { S.wins++; S.streak++; S.bestStreak = Math.max(S.bestStreak, S.streak); } else { S.losses++; S.streak = 0; }
  flush();
  renderBattleButtons();

  const log = $('battleLog'), out = $('battleResult');
  log.style.display = 'block'; log.replaceChildren(); out.replaceChildren();
  const add = (...kids) => { log.append(h('div', { class: 'bl-round' }, ...kids)); log.scrollTop = log.scrollHeight; };
  add(h('b', { text: `Opponent: ${res.bot.persona.name}` }), h('span', { class: 'bl-dim', text: ` · ${LEVELS[level - 1].name} (Lv${level})` }));
  for (let i = 0; i < res.rounds.length; i++) {
    await sleep(450);
    const r = res.rounds[i];
    add(`R${i + 1}: `, h('span', { style: { color: RARITY_COLOR[r.player.rarity] }, text: `${r.player.name} (${r.player.type})` }),
      ` ${r.pp} vs ${r.bp} `, h('span', { style: { color: RARITY_COLOR[r.bot.rarity] }, text: `${r.bot.name} (${r.bot.type})` }),
      ' → ', h('b', { class: r.win ? 'bl-win' : 'bl-loss', text: r.win ? 'WIN' : 'LOSS' }));
  }
  await sleep(350);
  if (res.won) {
    out.append(h('span', { style: { color: 'var(--green)' }, text: `Victory ${res.roundWins}-${3 - res.roundWins}! +${fmt(reward)} 💰` }));
    if (tax > 0.05) out.append(h('span', { class: 'bl-dim', style: { fontSize: '.8rem' }, text: ` (streak tax −${Math.round(tax * 100)}%)` }));
    if (S.streak >= 3) toast(`Streak ${S.streak} — bots get tougher`);
  } else {
    out.append(h('span', { style: { color: 'var(--accent)' }, text: `Defeat ${res.roundWins}-${3 - res.roundWins} · +${fmt(reward)} 💰` }));
  }
  fighting = false;
  renderTop();
  renderBattle();
}

function renderBattleButtons() {
  const cdLeft = Math.max(0, S.battleCD - Date.now());
  $('startBattleBtn').disabled = fighting || S.team.length !== 3 || cdLeft > 0;
  $('battleCooldown').textContent = cdLeft > 0 ? `Cooldown: ${Math.ceil(cdLeft / 1000)}s` : '';
}

function toggleTeam(card) {
  const i = S.team.indexOf(card.id);
  if (i >= 0) S.team.splice(i, 1);
  else if (S.team.length < 3) S.team.push(card.id);
  else { toast('Team full (3 max)'); return; }
  save(); renderTeam(); syncPoolSelection();
}

/** Marks selected cards in the already-rendered pool without rebuilding it. */
function syncPoolSelection() {
  [...$('battleCardPool').children].forEach((el, i) => {
    const c = poolGrid.items[i];
    if (c) el.classList.toggle('selected', S.team.includes(c.id));
  });
}

function autoPickTeam() {
  const owned = CARDS.filter(c => S.collection[c.id]).sort((a, b) => cardPower(b) - cardPower(a));
  if (owned.length < 3) { toast('Need at least 3 cards'); return; }
  S.team = owned.slice(0, 3).map(c => c.id);
  save(); renderBattle();
}

const poolGrid = makeGrid('battleCardPool', 'poolMore', (card, i, list) =>
  cardEl(card, { power: true, selected: S.team.includes(card.id), onclick: e => { e.stopPropagation(); toggleTeam(card); } }));

function renderTeam() {
  $('playerTeam').replaceChildren(...[0, 1, 2].map(i => {
    const c = CARD_BY_ID.get(S.team[i]);
    if (!c) return h('div', { class: 'team-slot', text: `Slot ${i + 1}` });
    return h('button', { type: 'button', class: 'team-slot filled', 'aria-label': `Remove ${c.name}`,
      onclick: () => { S.team.splice(i, 1); save(); renderTeam(); syncPoolSelection(); } },
      h('img', { src: c.img, alt: c.name }), h('span', { class: 'ty', text: `${c.type} · ${cardPower(c)}` }), h('span', { class: 'nm', text: c.name }));
  }));
  renderBattleButtons();
}

function renderBattle() {
  const lvl = currentLevel();
  $('botDiff').textContent = LEVELS[lvl - 1].name;
  $('adaptLevel').textContent = lvl;
  $('winStreak').textContent = S.streak;
  $('bestStreak').textContent = S.bestStreak;
  $('botLevelSel').value = S.botLevel;

  renderTeam();

  const typeFilter = $('poolType').value;
  const owned = CARDS.filter(c => S.collection[c.id] && (typeFilter === 'all' || c.type === typeFilter))
    .sort((a, b) => cardPower(b) - cardPower(a) || rarIdx(b.rarity) - rarIdx(a.rarity));
  if (!Object.keys(S.collection).length) {
    $('battleCardPool').replaceChildren(h('div', { class: 'empty-state', text: 'Open packs first.' }));
    $('poolMore').hidden = true;
  } else poolGrid.set(owned);
  renderBattleButtons();
}

/* ===================== MINES ===================== */
let M = null;
let mineLP = null, lastFlagAt = 0;

function mineNeighbors(i) {
  const n = M.size, x = i % n, y = (i / n) | 0, out = [];
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
    if (!dx && !dy) continue;
    const nx = x + dx, ny = y + dy;
    if (nx >= 0 && nx < n && ny >= 0 && ny < n) out.push(ny * n + nx);
  }
  return out;
}

function newMines() {
  const mode = MINE_MODES[S.mineMode];
  M = { ...mode, cells: Array.from({ length: mode.size ** 2 }, () => ({ mine: false, n: 0, open: false, flag: false })),
        placed: false, over: false, revealed: 0, flags: 0, startedAt: 0, flagMode: M ? M.flagMode : false };
  const board = $('mineBoard');
  board.style.setProperty('--n', mode.size);
  board.classList.remove('over');
  board.replaceChildren(...M.cells.map((_, i) => h('button', { type: 'button', class: 'mine-cell', dataset: { i }, 'aria-label': `Cell ${i + 1}` })));
  $('mineResult').replaceChildren();
  renderMineStats();
}

function placeMines(safe) {
  const blocked = new Set([safe, ...mineNeighbors(safe)]);
  const free = shuffle(M.cells.map((_, i) => i).filter(i => !blocked.has(i)));
  free.slice(0, M.mines).forEach(i => { M.cells[i].mine = true; });
  M.cells.forEach((c, i) => { if (!c.mine) c.n = mineNeighbors(i).filter(k => M.cells[k].mine).length; });
  M.placed = true;
  M.startedAt = Date.now();
}

const NUM_COLORS = ['', '#60a5fa', '#4ade80', '#f87171', '#c084fc', '#fbbf24', '#22d3ee', '#fb7185', '#a3a3a3'];
function paintCell(i) {
  const c = M.cells[i], el = $('mineBoard').children[i];
  el.className = 'mine-cell';
  el.textContent = '';
  el.style.color = '';
  if (c.open) {
    el.classList.add('revealed');
    if (c.mine) { el.classList.add('mine'); el.textContent = '💣'; }
    else if (c.n) { el.textContent = c.n; el.style.color = NUM_COLORS[c.n]; }
  } else if (c.flag) {
    el.classList.add('flagged'); el.textContent = '🚩';
    if (M.over && !c.mine) { el.classList.add('wrong'); el.textContent = '❌'; }
  }
}

function renderMineStats() {
  $('flagCount').textContent = M.flags;
  $('mineLeft').textContent = Math.max(0, M.mines - M.flags);
  if (!M.startedAt) $('mineTime').textContent = '0';
}

function mineLose() {
  M.over = true;
  M.cells.forEach((c, i) => { if (c.mine) c.open = true; if (c.mine || c.flag) paintCell(i); });
  $('mineBoard').classList.add('over');
  $('mineResult').replaceChildren(h('span', { style: { color: 'var(--accent)' }, text: 'Boom!' }));
}

function mineWin() {
  M.over = true;
  const secs = Math.floor((Date.now() - M.startedAt) / 1000);
  const reward = Math.round((MINE_REWARD.base + rand(0, MINE_REWARD.spread)) * M.mult);
  S.minesCleared++;
  $('mineTime').textContent = secs;
  $('mineBoard').classList.add('over');
  addCoins(reward);
  $('mineResult').replaceChildren(h('span', { style: { color: 'var(--green)' }, text: `Clear in ${secs}s! +${fmt(reward)} 💰` }));
}

function mineReveal(i) {
  if (M.over) return;
  const first = M.cells[i];
  if (first.open || first.flag) return;
  if (!M.placed) placeMines(i);
  if (first.mine) { first.open = true; paintCell(i); mineLose(); renderMineStats(); return; }
  const stack = [i];
  while (stack.length) {
    const j = stack.pop(), c = M.cells[j];
    if (c.open || c.flag) continue;
    c.open = true; M.revealed++; paintCell(j);
    if (c.n === 0) for (const k of mineNeighbors(j)) if (!M.cells[k].open && !M.cells[k].flag) stack.push(k);
  }
  renderMineStats();
  if (M.revealed === M.cells.length - M.mines) mineWin();
}

function mineFlag(i) {
  if (M.over) return;
  const c = M.cells[i];
  if (c.open) return;
  c.flag = !c.flag;
  M.flags += c.flag ? 1 : -1;
  lastFlagAt = Date.now();
  paintCell(i); renderMineStats();
}

/** Click an opened number whose flags already match → open the rest of its neighbours. */
function mineChord(i) {
  const c = M.cells[i];
  if (M.over || !c.open || !c.n) return;
  const nb = mineNeighbors(i);
  if (nb.filter(k => M.cells[k].flag).length !== c.n) return;
  nb.forEach(k => { if (!M.cells[k].flag && !M.cells[k].open) mineReveal(k); });
}

function mineTap(i) {
  if (M.flagMode) mineFlag(i);
  else if (M.cells[i].open) mineChord(i);
  else mineReveal(i);
}

function wireMines() {
  const board = $('mineBoard');
  const cellOf = e => { const b = e.target.closest('.mine-cell'); return b ? +b.dataset.i : -1; };
  board.addEventListener('pointerdown', e => {
    const i = cellOf(e); if (i < 0 || e.button > 0) return;
    board._lp = false;
    if (e.pointerType !== 'mouse') {
      clearTimeout(mineLP);
      mineLP = setTimeout(() => { board._lp = true; mineFlag(i); try { navigator.vibrate && navigator.vibrate(12); } catch { /* n/a */ } }, 450);
    }
  });
  const cancelLP = () => clearTimeout(mineLP);
  ['pointermove', 'pointercancel', 'pointerleave'].forEach(ev => board.addEventListener(ev, e => { if (ev !== 'pointermove' || Math.abs(e.movementX) + Math.abs(e.movementY) > 6) cancelLP(); }));
  board.addEventListener('pointerup', e => {
    cancelLP();
    const i = cellOf(e); if (i < 0 || e.button > 0) return;
    if (board._lp) { board._lp = false; return; }
    mineTap(i);
  });
  board.addEventListener('contextmenu', e => {
    e.preventDefault();
    const i = cellOf(e);
    if (i >= 0 && Date.now() - lastFlagAt > 700) mineFlag(i);
  });
  // keyboard: Enter/Space on a focused cell (pointer events don't fire for those)
  board.addEventListener('click', e => { if (e.detail === 0) { const i = cellOf(e); if (i >= 0) mineTap(i); } });
}

/* ===================== COLLECTION / CATALOG ===================== */
const countOf = c => (S.collection[c.id] || {}).count || 0;
let cardsSort = {
  rarity: (a, b) => rarIdx(b.rarity) - rarIdx(a.rarity) || a.name.localeCompare(b.name),
  recent: (a, b) => S.collection[b.id].first - S.collection[a.id].first,
  count: (a, b) => countOf(b) - countOf(a) || rarIdx(b.rarity) - rarIdx(a.rarity),
  power: (a, b) => cardPower(b) - cardPower(a),
  name: (a, b) => a.name.localeCompare(b.name),
  girls: (a, b) => (b.girls || 0) - (a.girls || 0) || rarIdx(b.rarity) - rarIdx(a.rarity)
};

const colGrid = makeGrid('collectionGrid', 'colMore', (card, i, list) => {
  const el = cardEl(card, { list, index: i });
  const n = countOf(card);
  if (n > 1) el.append(h('div', { class: 'count-badge', text: '×' + n }));
  return el;
});
const catGrid = makeGrid('catalogGrid', 'catMore', (card, i, list) => {
  const el = cardEl(card, { list, index: i });
  if (!S.collection[card.id]) { el.style.filter = 'brightness(.65) saturate(.7)'; el.style.opacity = '.82'; }
  return el;
});

function dupeSummary(maxRarity) {
  let total = 0, count = 0;
  for (const [id, e] of Object.entries(S.collection)) {
    const c = CARD_BY_ID.get(Number(id));
    if (e.count > 1 && rarIdx(c.rarity) <= rarIdx(maxRarity)) { total += SELL_VALUE[c.rarity] * (e.count - 1); count += e.count - 1; }
  }
  return { total, count };
}

function renderSellButton() {
  const { total, count } = dupeSummary($('sellMax').value);
  const b = $('sellDupesBtn');
  b.textContent = count ? `Sell ${count} for ${fmt(total)} 💰` : 'No dupes';
  b.disabled = !count;
}

function sellDupes() {
  const max = $('sellMax').value, { total, count } = dupeSummary(max);
  if (!count || !confirm(`Sell ${count} spare cop${count === 1 ? 'y' : 'ies'} (${max} and below) for ${fmt(total)} coins? You keep one of each card.`)) return;
  for (const [id, e] of Object.entries(S.collection)) {
    if (e.count > 1 && rarIdx(CARD_BY_ID.get(Number(id)).rarity) <= rarIdx(max)) e.count = 1;
  }
  addCoins(total);
  toast(`Sold ${count} dupes +${fmt(total)} 💰`);
  renderCollection();
}

function renderCollection() {
  const owned = CARDS.filter(c => S.collection[c.id]);
  $('ownedCount').textContent = owned.length;
  $('totalCount').textContent = CARDS.length;
  $('dupeCount').textContent = owned.reduce((s, c) => s + countOf(c) - 1, 0);

  $('rarityProgress').replaceChildren(...RARITIES.filter(r => POOL[r].length).reverse().map(r =>
    h('span', { class: 'pr' }, h('b', { style: { color: RARITY_COLOR[r] }, text: cap(r) }), ` ${POOL[r].filter(c => S.collection[c.id]).length}/${POOL[r].length}`)));

  const q = $('colSearch').value.trim().toLowerCase(), rar = $('colRarity').value;
  const list = owned.filter(c => (rar === 'all' || c.rarity === rar) && (!q || c.name.toLowerCase().includes(q)))
    .sort(cardsSort[$('sortCol').value] || cardsSort.rarity);
  $('emptyCollection').style.display = owned.length ? 'none' : 'block';
  $('emptyCollection').textContent = owned.length ? '' : 'No cards yet — open a pack!';
  colGrid.set(list);
  renderSellButton();
}

function renderCatalog() {
  $('catalogTotal').textContent = CARDS.length;
  const q = $('catSearch').value.trim().toLowerCase();
  const fr = $('filterRarity').value, fg = $('filterGirls').value, fo = $('filterOwned').value;
  const list = CARDS.filter(c =>
    (fr === 'all' || c.rarity === fr) &&
    (fg === 'all' || (fg === '1' ? (c.girls || 1) <= 1 : (c.girls || 0) >= +fg)) &&
    (fo === 'all' || (fo === 'owned') === !!S.collection[c.id]) &&
    (!q || c.name.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q)))
    .sort((a, b) => rarIdx(b.rarity) - rarIdx(a.rarity) || a.name.localeCompare(b.name));
  $('catalogShown').textContent = list.length;
  catGrid.set(list);
}

/* ===================== BACKUP ===================== */
function exportSave() {
  flush();
  const blob = new Blob([JSON.stringify({ app: 'forbidden-packs', v: 6, data: S })], { type: 'application/json' });
  const a = h('a', { href: URL.createObjectURL(blob), download: `forbidden-packs-${new Date().toISOString().slice(0, 10)}.json` });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast('Backup downloaded');
}

function importSave(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const json = JSON.parse(reader.result);
      if (json.app !== 'forbidden-packs' || !json.data) throw new Error('bad file');
      const next = sanitize(json.data);
      if (!confirm(`Replace current progress with this backup? (${Object.keys(next.collection).length} cards, ${fmt(next.coins)} coins)`)) return;
      S = next; flush(); location.reload();
    } catch { toast('That isn’t a valid backup file'); }
  };
  reader.readAsText(file);
}

function resetAll() {
  if (!confirm('Reset collection, coins, and battle record? This cannot be undone (export a backup first!).')) return;
  S = defaultState(); flush();
  $('pullResults').replaceChildren(); $('pullSummary').replaceChildren();
  $('battleLog').style.display = 'none'; $('battleResult').replaceChildren();
  toast('Reset complete');
  renderTop(); showSection(currentSection);
}

/* ===================== MODAL ===================== */
const modalCtx = { list: [], i: 0, opener: null };
const modalOpen = () => $('modal').classList.contains('show');

function openModal(list, i, opener) {
  modalCtx.list = list; modalCtx.i = i; modalCtx.opener = opener || document.activeElement;
  $('modal').classList.add('show');
  renderModal();
  $('closeModal').focus();
}
function closeModal() {
  $('modal').classList.remove('show');
  if (modalCtx.opener && document.contains(modalCtx.opener)) modalCtx.opener.focus({ preventScroll: true });
}
function stepModal(d) {
  const j = modalCtx.i + d;
  if (j < 0 || j >= modalCtx.list.length) return;
  modalCtx.i = j; renderModal();
}
function renderModal() {
  const card = modalCtx.list[modalCtx.i];
  $('modalImg').src = card.img;
  $('modalName').textContent = card.name;
  const tag = $('modalRarity');
  tag.textContent = card.rarity; tag.style.background = RARITY_COLOR[card.rarity] || '#888';
  $('modalType').textContent = card.type;
  $('modalGirls').textContent = card.cross ? '· Cross-verse' : card.girls >= 2 ? `· ${card.girls} girls` : '';
  $('modalDesc').textContent = card.desc;
  const n = countOf(card);
  $('modalMeta').textContent = `Power ${cardPower(card)} · ${n ? 'Owned ×' + n : 'Not owned'} · ${modalCtx.i + 1}/${modalCtx.list.length}`;
  $('modalPrev').disabled = modalCtx.i === 0;
  $('modalNext').disabled = modalCtx.i >= modalCtx.list.length - 1;
}

/* ===================== NAVIGATION / WIRING ===================== */
let currentSection = 'packs';
function showSection(name) {
  currentSection = name;
  document.querySelectorAll('.nav-btn').forEach(b => { const on = b.dataset.section === name; b.classList.toggle('active', on); if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  document.querySelectorAll('.section').forEach(s => s.classList.toggle('active', s.id === name));
  if (name === 'collection') renderCollection();
  else if (name === 'allcards') renderCatalog();
  else if (name === 'battle') renderBattle();
  else if (name === 'mines' && (!M || M.over)) newMines();
  else if (name === 'packs') { renderTop(); renderOdds(); }
}

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
function fillSelect(id, entries, value) {
  const sel = $(id);
  sel.replaceChildren(...entries.map(([v, label]) => h('option', { value: v, text: label })));
  if (value !== undefined) sel.value = value;
}

function init() {
  // selects
  const rarOpts = [['all', 'All rarities'], ...RARITIES.filter(r => POOL[r].length).reverse().map(r => [r, cap(r)])];
  fillSelect('colRarity', rarOpts, 'all');
  fillSelect('filterRarity', rarOpts, 'all');
  fillSelect('sellMax', RARITIES.filter(r => POOL[r].length).map(r => [r, cap(r)]), 'epic');
  fillSelect('botLevelSel', [['auto', 'Auto (adaptive)'], ...LEVELS.map((l, i) => [String(i + 1), `Lv ${i + 1} · ${l.name}`])], S.botLevel);
  fillSelect('mineMode', Object.entries(MINE_MODES).map(([k, m]) => [k, m.label]), S.mineMode);

  // nav + packs
  document.querySelectorAll('.nav-btn').forEach(b => b.addEventListener('click', () => showSection(b.dataset.section)));
  document.querySelectorAll('[data-qty]').forEach(b => b.addEventListener('click', () => { S.qty = +b.dataset.qty; save(); renderTop(); }));
  $('openPackBtn').addEventListener('click', openPacks);
  $('dailyBtn').addEventListener('click', claimDaily);

  // battle
  $('startBattleBtn').addEventListener('click', startBattle);
  $('autoTeamBtn').addEventListener('click', autoPickTeam);
  $('clearTeamBtn').addEventListener('click', () => { S.team = []; save(); renderBattle(); });
  $('botLevelSel').addEventListener('change', e => { S.botLevel = e.target.value; save(); renderBattle(); });
  $('poolType').addEventListener('change', renderBattle);

  // mines
  wireMines();
  $('newMineBtn').addEventListener('click', newMines);
  $('mineMode').addEventListener('change', e => { S.mineMode = e.target.value; save(); newMines(); });
  $('flagModeBtn').addEventListener('click', () => { if (!M) newMines(); M.flagMode = !M.flagMode; $('flagModeBtn').setAttribute('aria-pressed', String(M.flagMode)); });

  // collection / catalog
  const reCol = debounce(renderCollection, 150), reCat = debounce(renderCatalog, 150);
  $('colSearch').addEventListener('input', reCol);
  ['colRarity', 'sortCol'].forEach(id => $(id).addEventListener('change', renderCollection));
  $('sellMax').addEventListener('change', renderSellButton);
  $('sellDupesBtn').addEventListener('click', sellDupes);
  $('catSearch').addEventListener('input', reCat);
  ['filterRarity', 'filterGirls', 'filterOwned'].forEach(id => $(id).addEventListener('change', renderCatalog));
  $('exportBtn').addEventListener('click', exportSave);
  $('importBtn').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', e => { const f = e.target.files[0]; if (f) importSave(f); e.target.value = ''; });
  $('resetCollection').addEventListener('click', resetAll);

  // modal
  $('closeModal').addEventListener('click', closeModal);
  $('modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
  $('modalPrev').addEventListener('click', () => stepModal(-1));
  $('modalNext').addEventListener('click', () => stepModal(1));
  document.addEventListener('keydown', e => {
    if (!modalOpen()) return;
    if (e.key === 'Escape') closeModal();
    else if (e.key === 'ArrowLeft') stepModal(-1);
    else if (e.key === 'ArrowRight') stepModal(1);
  });

  // other tab changed the save → pick it up instead of overwriting it later
  addEventListener('storage', e => {
    if (e.key !== SAVE_KEY || !e.newValue) return;
    try { S = sanitize(JSON.parse(e.newValue)); renderTop(); showSection(currentSection); } catch { /* ignore */ }
  });

  // single 0.5s ticker: cooldown text, daily timer, mines clock
  setInterval(() => {
    renderBattleButtons();
    renderDaily();
    if (M && M.startedAt && !M.over) $('mineTime').textContent = Math.floor((Date.now() - M.startedAt) / 1000);
  }, 500);

  renderTop(); renderOdds(); renderDaily();
}

init();
